# PYMMEP

This is a repository for the python module for use with the MultiModal Europarl Corpus.

NB. This is a git submodule of `mmep-corpus-process`.
